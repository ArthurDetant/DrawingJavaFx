package drawing.commands;

import drawing.DrawingPane;
import drawing.IShape;

import java.util.ArrayList;

public class RemoveCommand implements ICommand {
    private DrawingPane drawingPane;
    private ArrayList<IShape> savedShapes;


    public RemoveCommand(DrawingPane dpane){
        drawingPane = dpane;
        savedShapes = new ArrayList<IShape>();

    }

    @Override
    public void execute() {
        savedShapes.clear();
        savedShapes.addAll(drawingPane.getSelection());
        drawingPane.removeSelection();
    }

    @Override
    public void undo() {
        for (int j = 0; j <  savedShapes.size(); j++) {
            drawingPane.addShape(savedShapes.get(j));
        }
    }

    @Override
    public ICommand clone(){
        ICommand copy = new RemoveCommand(drawingPane);
        ((RemoveCommand) copy).savedShapes.addAll(this.savedShapes);
        return copy;
    }


}
