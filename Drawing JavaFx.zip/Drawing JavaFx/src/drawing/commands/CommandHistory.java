package drawing.commands;

import java.util.Stack;

public class CommandHistory {

    private Stack<ICommand> pile;

    public CommandHistory(){
        pile = new Stack<>();
    }


    public void exec(ICommand command){
        command.execute();
        pile.push(command.clone());
    }

    public void undo(){
        pile.lastElement().undo();
        pile.pop();

    }


}
