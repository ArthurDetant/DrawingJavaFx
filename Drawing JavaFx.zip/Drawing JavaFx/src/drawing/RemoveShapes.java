package drawing;

import drawing.commands.CommandHistory;
import drawing.commands.ICommand;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.List;

public class RemoveShapes implements EventHandler<ActionEvent> {
    private DrawingPane drawingPane;



    private ICommand remove;

    public RemoveShapes(ICommand c, DrawingPane dpane)
    {
        remove = c;
        drawingPane = dpane;
    }

    @Override
    public void handle(ActionEvent arg)
    {
        drawingPane.getHistory().exec(remove);
    }
}
